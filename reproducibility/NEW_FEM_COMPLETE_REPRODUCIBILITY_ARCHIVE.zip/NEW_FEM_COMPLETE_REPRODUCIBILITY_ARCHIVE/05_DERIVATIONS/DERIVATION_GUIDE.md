# Existing derivations and explicit gaps

Governing/constitutive energy and weak statement: 02_formulation, 05_finite_element.
Mechanical/electrode BC: 04_boundary_conditions; IC in figure producers.
Window moments/gradient coefficient and limiting cases: 03_particular_cases,
91_appendixA and source_notes. Worked closed-form/plane-stress/coupling route:
derive_k2_closed_form.py, worked_example.py and their JSON intermediates.
L1/Newmark: fem6_core.py plus manuscript and limiting-case scripts.
Independent beam frequencies, rational-alpha roots and uniform-curvature coupling:
run_independent_checks.py. Exact existing equations are extracted verbatim.

Parameter perturbation: sensitivity_tornado.py +/-10%; numerical-stack
sensitivity: run_sensitivity.py. Neither is statistical uncertainty or FIM.
Full separate nondimensionalization, FIM/CRLB/noise/likelihood/identified
parameters, thermal/nonlinear extensions and original experimental data:
NOT AVAILABLE / NOT IMPLEMENTED. No substitute derivation or result invented.
Historical source notes are preserved but current code/manuscript take precedence.
