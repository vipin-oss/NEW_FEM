# Existing governing equations — verbatim source extracts

Context and assumptions remain in the authoritative section files. No new equations invented.


## 02_OVERLEAF/sec/02_formulation.tex:23
```latex
\begin{equation}
  \bar\eta_{ijk}(\bm{x}) = \frac{1}{A_{\mathcal W}}
     \int_{\mathcal W} \eta_{ijk}(\bm{x}+\bm{s})\,\mathrm{d}\bm{s}.
  \label{eq:average}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:29
```latex
\begin{equation}
  \eta_{ijk}(\bm{x}+\bm{s}) \simeq \eta_{ijk}(\bm{x})
     + s_m\,\eta_{ijk,m}(\bm{x}) + \tfrac12 s_m s_n\,\eta_{ijk,mn}(\bm{x}),
  \label{eq:expand}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:36
```latex
\begin{equation}
  \bar\eta_{ijk} \simeq \eta_{ijk} + \tfrac12 M_{mn}\,\eta_{ijk,mn},
  \qquad
  M_{mn} = \frac{1}{A_{\mathcal W}}\int_{\mathcal W} s_m s_n \,\mathrm{d}\bm{s},
  \label{eq:Mdef}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:47
```latex
\begin{equation}
  M^{\rm cuboid}_{ii} = \frac{a_i^2}{3},\qquad
  M^{\rm ellipse}_{ii} = \frac{a_i^2}{4},\qquad
  M^{\rm ellipsoid}_{ii} = \frac{a_i^2}{5},
  \label{eq:Mshapes}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:56
```latex
\begin{equation}
  M_{11}(\theta)=M_{11}\cos^{2}\theta+M_{22}\sin^{2}\theta,\qquad
  M_{12}(\theta)=\tfrac12\left(M_{22}-M_{11}\right)\sin2\theta,
  \label{eq:Mrot2}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:82
```latex
\begin{equation}
  \varepsilon_{ij} = \tfrac12\left(u_{i,j}+u_{j,i}\right),\qquad
  \eta_{ijk} = \partial_k \varepsilon_{ij} = \tfrac12\left(
  u_{i,jk}+u_{j,ik}\right),
  \label{eq:strain}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:89
```latex
\begin{equation}
  \left\{u_1,\; \partial_1u_1,\; \partial_2u_1,\; \partial_{12}u_1,\;
         u_2,\; \partial_1u_2,\; \partial_2u_2,\; \partial_{12}u_2\right\},
  \label{eq:dofs}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:101
```latex
\begin{equation}
  u(\xi,\eta) = \sum_{a=1}^{4}\Big[N^{00}_{a}u_a + N^{10}_{a}u_{,x}\big|_a
    + N^{01}_{a}u_{,y}\big|_a + N^{11}_{a}u_{,xy}\big|_a\Big],
  \label{eq:interp}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:118
```latex
\begin{equation}
  \Pi_{\rm el} = \tfrac12\int_\Omega \varepsilon_{ij} C_{ijkl}
        \varepsilon_{kl}\,\mathrm{d}A ,
  \label{eq:Eel}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:125
```latex
\begin{equation}
  \Pi_{\rm gr} = \tfrac14\int_\Omega M_{mn}\,
        \varepsilon_{ij,m}\,C_{ijkl}\,\varepsilon_{kl,n}\,\mathrm{d}A ,
  \label{eq:Egrad}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:131
```latex
\begin{equation}
  \Pi_{\rm pz} = -\int_\Omega e_{kij} E_k \varepsilon_{ij}\,\mathrm{d}A
  \qquad\text{and}\qquad
  \Pi_{\rm dl} = -\tfrac12\int_\Omega \kappa_{ij} E_i E_j\,\mathrm{d}A ,
  \label{eq:Epiezo}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:139
```latex
\begin{equation}
  \Pi_{\rm fx} = -\int_\Omega \mu_{kijl} E_k \eta_{ijl}\,\mathrm{d}A ,
  \label{eq:Eflexo}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:147
```latex
\begin{equation}
  \Pi = \Pi_{\rm el} + \Pi_{\rm gr} + \Pi_{\rm pz} + \Pi_{\rm dl}
        + \Pi_{\rm fx} - W_{\rm ext},
  \label{eq:energy}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:155
```latex
\begin{equation}
  \mu_{kijl} = \mu\,\delta_{ij}\delta_{kl},
  \qquad \mu = 10^{-6}\ \si{\coulomb\per\meter},
  \label{eq:muexplicit}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:165
```latex
\begin{equation}
  \sigma_{ij} = \frac{\partial \Pi}{\partial \varepsilon_{ij}}
              = C_{ijkl}\,\varepsilon_{kl} - e_{kij} E_k ,
  \label{eq:sig}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:171
```latex
\begin{equation}
  \varsigma_{ijm} = \frac{\partial \Pi}{\partial \varepsilon_{ij,m}}
              = \tfrac12 M_{mn}\,C_{ijkl}\,\varepsilon_{kl,n}
                - \mu_{kijm}\,E_k ,
  \label{eq:tau}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:178
```latex
\begin{equation}
  D_k = -\frac{\partial \Pi}{\partial E_k}
              = e_{kij}\,\varepsilon_{ij} + \kappa_{kl}\,E_l
                + \mu_{kijl}\,\eta_{ijl},
  \label{eq:D}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:189
```latex
\begin{equation}
  \varsigma_{ijm} = \tfrac12 M_{mn}\,C_{ijkl}\,\varepsilon_{kl,n}
                    - \mu E_m\delta_{ij},
  \qquad
  D_k = e_{kij}\varepsilon_{ij} + \kappa_{kl}E_l
        + \mu\,\partial_k\left(\varepsilon_{xx}+\varepsilon_{yy}\right),
  \label{eq:Dexplicit}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:241
```latex
\begin{equation}
  C^{p}_{ij} = C_{ij} - \frac{C_{i3}C_{j3}}{C_{33}},
  \label{eq:Cp}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:246
```latex
\begin{equation}
  e^{p}_{ij} = e_{ij} - \frac{C_{i3}}{C_{33}}\,e_{3j},
  \qquad
  \kappa^{p}_{ij} = \kappa_{ij} + \frac{e_{3i}e_{3j}}{C_{33}},
  \label{eq:ep}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:269
```latex
\begin{equation}
  {}^{C}\!D_t^{\alpha}f(t) = \frac{1}{\Gamma(1-\alpha)}
     \int_{0}^{t}\frac{\dot f(t')}{(t-t')^{\alpha}}\,\mathrm{d}t',
  \qquad 0<\alpha\le1,
  \label{eq:caputo}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:278
```latex
\begin{equation}
  \sigma(t) = K\,\varepsilon(t) + K\,\tau^{\alpha}\,
              {}^{C}\!D_t^{\alpha}\varepsilon(t),
  \label{eq:kv}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:287
```latex
\begin{equation}
  K^{*}(\omega) = K\left[1+(\mathrm{i}\omega\tau)^{\alpha}\right],
  \label{eq:kvfreq}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:300
```latex
\begin{equation}
  {}^{C}\!D_t^{\alpha}\varepsilon(t_n) \approx
  \frac{1}{\Gamma(2-\alpha)}\sum_{k=1}^{n} b_{n-k}\,
  \frac{\varepsilon^{k}-\varepsilon^{k-1}}{\Delta t^{\alpha}},
  \label{eq:l1}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:307
```latex
\begin{equation}
  b_j=(j+1)^{1-\alpha}-j^{1-\alpha},\qquad b_0=1,
  \label{eq:bdef}
\end{equation}
```

## 02_OVERLEAF/sec/02_formulation.tex:331
```latex
\begin{align}
  \sigma_{ij,j} - \varsigma_{ijm,jm} + \rho\,\ddot u_i &= 0,
  \label{eq:gov1}\\
  D_{k,k} &= 0,
  \label{eq:gov2}
\end{align}
```

## 02_OVERLEAF/sec/02_formulation.tex:341
```latex
\begin{equation}
  \left(C_{ijkl}\varepsilon_{kl}\right)_{,j}
    - \left[\tfrac12 M_{mn}C_{ijkl}\varepsilon_{kl,n}\right]_{,jm}
    + \mu\left(\nabla\cdot\bm{E}\right)_{,i} + \rho\ddot u_i = 0,
  \qquad
  \kappa_{kl}E_{l,k} = -\mu\,\partial_k\partial_k
    \left(\varepsilon_{xx}+\varepsilon_{yy}\right),
  \label{eq:govexp}
\end{equation}
```

## 02_OVERLEAF/sec/03_particular_cases.tex:24
```latex
\begin{equation}
  \begin{aligned}
  \Pi \to {}&\tfrac12\int_\Omega \varepsilon_{ij} C_{ijkl}\varepsilon_{kl}
    \,\mathrm{d}A - \int_\Omega e_{kij}E_k\varepsilon_{ij}\,\mathrm{d}A\\
    &- \tfrac12\int_\Omega\kappa_{ij}E_iE_j\,\mathrm{d}A
    - \int_\Omega \mu_{kijl}E_k\eta_{ijl}\,\mathrm{d}A .
  \end{aligned}
  \label{eq:limitM}
\end{equation}
```

## 02_OVERLEAF/sec/03_particular_cases.tex:86
```latex
\begin{equation}
  \zeta = \frac{\tau K}{2\sqrt{KM}} = \frac{\omega\tau}{2},
  \label{eq:limitKV}
\end{equation}
```

## 02_OVERLEAF/sec/04_boundary_conditions.tex:19
```latex
\begin{equation}
  t_i = \sigma_{ij}n_j - \partial_m\!\left(\varsigma_{ijm}\right)n_j
      + \partial_t\!\left(\varsigma_{ijm}\,t_m n_j\right),
  \label{eq:traction}
\end{equation}
```

## 02_OVERLEAF/sec/04_boundary_conditions.tex:25
```latex
\begin{equation}
  m_i = \varsigma_{ijm}\,n_j n_m ,
  \label{eq:doubletraction}
\end{equation}
```

## 02_OVERLEAF/sec/04_boundary_conditions.tex:39
```latex
\begin{equation}
  \text{clamped: } u_i=0,\ u_{i,j}n_j=0;\qquad
  \text{simply supported: } u_i=0,\ m_i=0;\qquad
  \text{free: } t_i=0,\ m_i=0 .
  \label{eq:bcmech}
\end{equation}
```

## 02_OVERLEAF/sec/04_boundary_conditions.tex:67
```latex
\begin{equation}
  K_{oc} = K_{sc} + \frac{1}{\beta}\, d\,d^{\mathsf T},
  \label{eq:rankone}
\end{equation}
```

## 02_OVERLEAF/sec/04_boundary_conditions.tex:75
```latex
\begin{equation}
  k_j^2=\frac{\omega_{oc,j}^2-\omega_{sc,j}^2}{\omega_{oc,j}^2},
  \label{eq:k2mode}
\end{equation}
```

## 02_OVERLEAF/sec/04_boundary_conditions.tex:82
```latex
\begin{equation}
  x = \frac{d^{\mathsf T}K_{uu}^{-1}d}{\beta},\qquad
  k^2 = \frac{x}{1+x},
  \label{eq:kstatic}
\end{equation}
```

## 02_OVERLEAF/sec/05_finite_element.tex:21
```latex
\begin{multline}
  \int_\Omega \delta\varepsilon_{ij}\,C_{ijkl}\,\varepsilon_{kl}\,\mathrm{d}A
  + \tfrac12\int_\Omega \delta\varepsilon_{ij,m}\,M_{mn}\,C_{ijkl}\,
     \varepsilon_{kl,n}\,\mathrm{d}A
  - \int_\Omega \delta\varepsilon_{ij}\,e_{kij}\,E_k\,\mathrm{d}A \\
  - \int_\Omega \delta\varepsilon_{ij,m}\,\mu_{kijm}\,E_k\,\mathrm{d}A
  - \int_\Omega \delta E_k\left(e_{kij}\varepsilon_{ij}
     + \kappa_{kl}E_l + \mu_{kijl}\eta_{ijl}\right)\mathrm{d}A
  = \delta W_{\rm ext}
  + \int_{\Gamma}\left(\delta u_i\,t_i + \delta u_{i,j}n_j\,m_i\right)
    \mathrm{d}s ,
  \label{eq:weak}
\end{multline}
```

## 02_OVERLEAF/sec/05_finite_element.tex:50
```latex
\begin{equation}
  \varepsilon = B(\xi,\eta)\,\bm{u}^e,\qquad
  \eta_k = \partial_k\varepsilon = B_{,k}(\xi,\eta)\,\bm{u}^e,
  \label{eq:Bmat}
\end{equation}
```

## 02_OVERLEAF/sec/05_finite_element.tex:62
```latex
\begin{equation}
  K_e=\int_{\Omega_e} B^{\mathsf T}C\,B\,\mathrm{d}A ,
  \label{eq:Ke}
\end{equation}
```

## 02_OVERLEAF/sec/05_finite_element.tex:67
```latex
\begin{equation}
  K_{g,e}=\tfrac12\int_{\Omega_e} M_{mn}B_{,m}^{\mathsf T}C\,B_{,n}\,\mathrm{d}A ,
  \label{eq:Kg}
\end{equation}
```

## 02_OVERLEAF/sec/05_finite_element.tex:73
```latex
\begin{equation}
  B_e=\int_{\Omega_e} B^{\mathsf T}e^{\mathsf T}\nabla N_\phi\,\mathrm{d}A
     +\int_{\Omega_e} B_{,k}^{\mathsf T}\mu\,\nabla N_\phi\,\mathrm{d}A ,
  \label{eq:Be}
\end{equation}
```

## 02_OVERLEAF/sec/05_finite_element.tex:79
```latex
\begin{equation}
  C_{\phi,e}=\int_{\Omega_e}\kappa\,\nabla N_\phi\cdot\nabla N_\phi\,\mathrm{d}A ,
  \label{eq:Cphi}
\end{equation}
```

## 02_OVERLEAF/sec/05_finite_element.tex:92
```latex
\begin{equation}
  \begin{bmatrix} K & B \\ B^{\mathsf T} & -C_\phi \end{bmatrix}
  \begin{bmatrix} \bm{u} \\ \bm{\phi}\end{bmatrix}
  = \begin{bmatrix} \bm{f} \\ \bm{q}\end{bmatrix},
  \label{eq:saddle}
\end{equation}
```

## 02_OVERLEAF/sec/05_finite_element.tex:102
```latex
\begin{equation}
  K_{\rm cond} = K + B\,C_\phi^{-1}B^{\mathsf T},
  \qquad
  \bm{q}_{\rm cond} = \bm{q} + B\,C_\phi^{-1}\bm{q}_\phi ,
  \label{eq:schur}
\end{equation}
```

## 02_OVERLEAF/sec/05_finite_element.tex:110
```latex
\begin{equation}
  d = B\,C_\phi^{-1}\bm{q}_\phi ,\qquad
  \beta = \bm{q}_\phi^{\mathsf T}C_\phi^{-1}\bm{q}_\phi ,
  \label{eq:dbeta}
\end{equation}
```

## 02_OVERLEAF/sec/05_finite_element.tex:117
```latex
\begin{equation}
  Q = d^{\mathsf T}\bm{u} - \beta V,
  \label{eq:electrode}
\end{equation}
```

## 02_OVERLEAF/sec/05_finite_element.tex:124
```latex
\begin{equation}
  V_{\rm oc} = \frac{d^{\mathsf T}\bm{u}}{\beta},
  \label{eq:voc}
\end{equation}
```

## 02_OVERLEAF/sec/05_finite_element.tex:141
```latex
\begin{equation}
  M\bm{a}^{n+1} + K\bm{u}^{n+1} + \frac{K_{\rm mem}}{\Gamma(2-\alpha)}
  \sum_{k=0}^{n} b_{k}\,\frac{\bm{u}^{n+1-k}-\bm{u}^{n-k}}{\Delta t^{\alpha}}
  = \bm{f}^{n+1},
  \label{eq:step}
\end{equation}
```

## 02_OVERLEAF/sec/05_finite_element.tex:156
```latex
\begin{equation}
  \bm{u}(t) \simeq \Phi\,\bm{q}(t),\qquad
  \Phi^{\mathsf T}M\Phi = I,\qquad
  \Phi^{\mathsf T}K_{sc}\Phi = \mathrm{diag}(\omega_i^2),
  \label{eq:modal}
\end{equation}
```

## 02_OVERLEAF/sec/05_finite_element.tex:166
```latex
\begin{equation}
  \bm{u}^{n+1} = \bm{u}^{n} + \Delta t\,\bm{v}^{n}
     + \Delta t^{2}\left[\left(\tfrac12-\beta\right)\bm{a}^{n}
       + \beta\,\bm{a}^{n+1}\right],
  \qquad
  \bm{v}^{n+1} = \bm{v}^{n} + \Delta t\left[(1-\gamma)\bm{a}^{n}
       + \gamma\,\bm{a}^{n+1}\right],
  \label{eq:newmark}
\end{equation}
```

## 02_OVERLEAF/sec/05_finite_element.tex:176
```latex
\begin{equation}
  \left[M + \beta\Delta t^{2}K +
    \frac{\beta\,\Delta t^{2-\alpha}}{\Gamma(2-\alpha)}K_{\rm mem}\right]
  \bm{a}^{n+1} = \bm{r}^{n+1},
  \label{eq:stepA}
\end{equation}
```

## 02_OVERLEAF/sec/06_validation.tex:78
```latex
\begin{equation}
  x=\frac{e^{\mathsf T}C_{p}^{-1}e}{\kappa}=1.2768,
  \qquad
  k^{2}=\frac{x}{1+x}=0.5608 ,
  \label{eq:xclosed}
\end{equation}
```

## 02_OVERLEAF/sec/06_validation.tex:158
```latex
\begin{equation}
  M_{11}=\frac{a_1^{2}}{3}=3.000\times10^{-12}\ \si{\meter\squared},\qquad
  M_{22}=\frac{a_2^{2}}{3}=3.333\times10^{-13}\ \si{\meter\squared},
  \label{eq:Mnumber}
\end{equation}
```

## 02_OVERLEAF/sec/06_validation.tex:187
```latex
\begin{equation}
  x_{\rm FEM}=\frac{d^{\mathsf T}K_{sc}^{-1}d}{\beta}=1.2631,
  \qquad
  k^{2}_{\rm FEM}=\frac{x_{\rm FEM}}{1+x_{\rm FEM}}=0.5581 ,
  \label{eq:xFEM}
\end{equation}
```

## 02_OVERLEAF/sec/06_validation.tex:199
```latex
\begin{equation}
  x=\frac{3\mu^{2}}{C^{p}_{xx}\,h^{2}\,\kappa_{33}}
   =\frac{3\,(10^{-6})^{2}}{1.6946\times10^{11}\cdot(10^{-6})^{2}\cdot
     4.9583\times10^{-10}}
   =3.5704\times10^{-4}
  \label{eq:xflexo}
\end{equation}
```

## 02_OVERLEAF/sec/06_validation.tex:210
```latex
\begin{equation}
  \alpha=0.5:\; (b_0,b_1,b_2)=(1,\;0.414214,\;0.317837),\qquad
  \alpha=0.7:\; (b_0,b_1,b_2)=(1,\;0.231144,\;0.159245),
  \label{eq:bweights}
\end{equation}
```

## 02_OVERLEAF/sec/06_validation.tex:216
```latex
\begin{equation}
  \delta=\ln\frac{A_k}{A_{k+1}},\qquad
  \zeta_{\rm eff}=\frac{\delta}{\sqrt{4\pi^{2}+\delta^{2}}} ,
  \label{eq:zeta}
\end{equation}
```

## 02_OVERLEAF/sec/08_limitations.tex:24
```latex
\begin{equation}
  V = \frac{\mu\,\kappa_c\,h}{\kappa_{33}},
  \label{eq:muV}
\end{equation}
```

## 02_OVERLEAF/sec/08_limitations.tex:38
```latex
\begin{equation}
  \tan\delta=\frac{(\omega\tau)^{\alpha}\sin(\pi\alpha/2)}
     {1+(\omega\tau)^{\alpha}\cos(\pi\alpha/2)}.
  \label{eq:tandelta}
\end{equation}
```

## 02_OVERLEAF/sec/08_limitations.tex:45
```latex
\begin{equation}
  \zeta=\frac{(\omega\tau)^{\alpha}\sin(\pi\alpha/2)}{2}
  \quad\Longrightarrow\quad
  \delta\approx\pi(\omega\tau)^{\alpha}\sin(\pi\alpha/2).
  \label{eq:zetasmall}
\end{equation}
```

## 02_OVERLEAF/sec/91_appendixA.tex:15
```latex
\begin{equation}
  M_{mn} = \frac{1}{|\mathcal{W}|}\int_{\mathcal W} s_m s_n \,\mathrm{d}\bm{s},
  \label{eq:appM}
\end{equation}
```

## 02_OVERLEAF/sec/91_appendixA.tex:29
```latex
\begin{equation}
  M_{11} = \frac{1}{4a_1a_2}\int_{-a_1}^{a_1}\!\!\int_{-a_2}^{a_2}
           s_1^{2}\,\mathrm{d}s_1\,\mathrm{d}s_2
         = \frac{1}{4a_1a_2}\cdot 2a_2\cdot\frac{2a_1^{3}}{3}
         = \frac{a_1^{2}}{3},
  \label{eq:Mcub}
\end{equation}
```

## 02_OVERLEAF/sec/91_appendixA.tex:43
```latex
\begin{equation}
  M_{11} = \frac{\pi a_1^{3}a_2/4}{\pi a_1a_2} = \frac{a_1^{2}}{4},
  \qquad M_{22}=\frac{a_2^{2}}{4}.
  \label{eq:Mell}
\end{equation}
```

## 02_OVERLEAF/sec/91_appendixA.tex:52
```latex
\begin{equation}
  M_{11} = \frac{a_1^{2}}{5},\qquad
  M_{22}=\frac{a_2^{2}}{5},\qquad
  M_{33}=\frac{a_3^{2}}{5}.
  \label{eq:Mellip}
\end{equation}
```

## 02_OVERLEAF/sec/91_appendixA.tex:72
```latex
\begin{equation}
  \begin{aligned}
  M_{11}(\theta) &= M_{11}\cos^{2}\theta + M_{22}\sin^{2}\theta,\\
  M_{22}(\theta) &= M_{11}\sin^{2}\theta + M_{22}\cos^{2}\theta,\\
  M_{12}(\theta) &= \tfrac12\left(M_{22}-M_{11}\right)\sin2\theta.
  \end{aligned}
  \label{eq:Mrot}
\end{equation}
```
