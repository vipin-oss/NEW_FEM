from pathlib import Path
import argparse,shutil
R=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--with-baseline',action='store_true');a=p.parse_args()
w=R/'04_REPRODUCTION/workspace'
if w.exists():raise SystemExit('Existing workspace: move/remove deliberately before preparing again')
w.mkdir()
for s,d in [('01_PROGRAM/python','python'),('01_PROGRAM/matlab','matlab'),('02_OVERLEAF','Paper_12'),('05_DERIVATIONS/source_notes','docs')]:shutil.copytree(R/s,w/d)
shutil.copytree(R/'01_PROGRAM/manuscript_tools',w/'Paper_12',dirs_exist_ok=True)
(w/'results').mkdir()
if a.with_baseline:
 shutil.copytree(R/'03_DATA/results',w/'results',dirs_exist_ok=True)
 shutil.copytree(R/'02_OVERLEAF/figures',w/'results/figures/paper',dirs_exist_ok=True)
print('Prepared',w.relative_to(R),'baseline' if a.with_baseline else 'EMPTY results')
