# Exact execution order

From archive root: prepare.py, reproduce.py, compare_outputs.py.
Inside reconstructed workspace, wrapper bootstraps run_demos.py then FULL
run_all.py runs these stages:

1. python3 python/run_verification.py
2. python3 python/run_flexo_check.py
3. python3 python/run_material_check.py
4. python3 python/run_memory_variants.py
5. python3 python/run_dt_study.py
6. python3 python/run_coupling_check.py
7. python3 python/run_mode_tracking.py
8. python3 python/run_reduction_mac.py
9. python3 python/run_application_table.py
10. python3 python/derive_k2_closed_form.py
11. python3 python/run_independent_checks.py
12. python3 python/audit_abstract_claims.py
13. python3 python/run_config_table.py
14. python3 python/list_unverified.py
15. python3 python/length_budget.py
16. python3 python/run_sensitivity.py
17. python3 python/check_gradient_energy.py
18. python3 python/check_coupled_patch.py
19. python3 python/check_numerics.py
20. python3 python/sensitivity_tornado.py
21. python3 python/run_design_map.py
22. python3 python/run_demos.py
23. python3 python/run_paper_figures.py
24. python3 python/make_appendix_tables.py
25. python3 python/coupling_provenance.py
26. python3 python/make_coupling_table.py
27. python3 python/check_coupling_provenance.py
28. python3 python/check_final_consistency.py
29. python3 python/worked_example.py
30. python3 python/check_paper_numbers.py
31. python3 python/check_paper_structure.py
32. python3 python/check_float_order.py

Second pass: make_paper_table.py, check_paper_numbers.py, check_float_order.py.
Wrapper final audits: number audit, float order, structure audit. Then compare.
TeX separately: pdfLaTeX → BibTeX → pdfLaTeX → pdfLaTeX.
No --reuse in fresh reproduction. Old historical README run times/order do not override this.
