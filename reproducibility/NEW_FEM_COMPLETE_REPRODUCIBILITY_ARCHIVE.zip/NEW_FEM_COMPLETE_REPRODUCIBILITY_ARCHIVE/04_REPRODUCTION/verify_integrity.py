from pathlib import Path
import hashlib,sys
R=Path(__file__).resolve().parents[1];bad=[];count=0
for line in (R/'SHA256SUMS.txt').read_text().splitlines():
 h,n=line.split('  ',1);p=R/n
 if p.resolve().is_relative_to(R) and p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==h:count+=1
 else:bad.append(n)
print('Verified',count,'files;',len(bad),'mismatches');print('\n'.join(bad));sys.exit(bool(bad))
