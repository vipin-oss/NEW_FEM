# Reproduce from scratch

Extract ZIP retaining its root folder. From that folder, with Python3.11+venv:
python3 04_REPRODUCTION/verify_integrity.py
python3 -m venv .venv
.venv/bin/python -m pip install --no-index --find-links 01_PROGRAM/wheelhouse -r 01_PROGRAM/requirements-lock.txt
.venv/bin/python 04_REPRODUCTION/prepare.py
.venv/bin/python 04_REPRODUCTION/reproduce.py
.venv/bin/python 04_REPRODUCTION/compare_outputs.py

This is the tested offline Linux x86_64 CPython3.11 route. Other platforms need
compatible dependencies/network and are untested. Minimum RAM/disk requirements
were NOT DOCUMENTED; allow working space for a venv, dense matrices and plots.
prepare.py starts with EMPTY results (no supplied cache). --with-baseline is
ONLY for redraw/re-audit, not fresh reproduction. Existing workspace is never
silently deleted: deliberately move/delete it before preparing anew.

Wrapper first computes demo.json because original early suite readers need it,
then runs FULL suite and number/float/structure audits. Stops on nonzero exit.
Original tolerances are not weakened. All logs, exit codes and elapsed times go
to reproduction_test; a new run replaces those evidence files, so copy them if
preservation is needed. Inspect summary.json even if a command returns zero.
Comparison reports all numeric/structural/pixel differences; PDF creation dates
alone are not physics. No common error tolerance was invented.

Compile separately: install full compatible TeX Live or upload 02_OVERLEAF to
Overleaf. Run build_manuscript.sh (or the four documented commands). Do not
compile concurrently with figure generation that writes manuscript assets.
Use canonical 02_OVERLEAF for shipped source or workspace/Paper_12 for fresh
outputs. Inspect every page/log; source checks cannot certify absence of fatal
errors. No TeX compile was performed by this package test.

Modify canonical 01_PROGRAM source/settings, record change in CHANGELOG, prepare
a new workspace and rerun full workflow. Promote ONLY reviewed active tables,
figures and JSON, preserving the old baseline. Do not blindly copy unprinted
legacy tables into the paper. Populate true frontmatter, confirm bibliography,
material/funding/rights, add reviewed manuscript PDF, update status/manifests,
and run refresh_integrity.py. Reproduction is not permission to re-submit.
