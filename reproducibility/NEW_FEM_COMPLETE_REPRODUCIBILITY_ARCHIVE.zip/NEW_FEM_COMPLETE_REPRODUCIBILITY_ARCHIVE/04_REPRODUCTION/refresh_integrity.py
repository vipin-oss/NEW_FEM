from pathlib import Path
import csv,io,hashlib,zipfile,sys
R=Path(__file__).resolve().parents[1]
files=sorted(p for p in R.rglob('*') if p.is_file() and p.name not in ['SHA256SUMS.txt','file_manifest_sha256.csv'] and not any(x in p.relative_to(R).parts for x in ['workspace','__pycache__','.venv','.git']))
b=io.StringIO();c=csv.writer(b);c.writerow(['relative_path','bytes','sha256'])
for p in files:c.writerow([p.relative_to(R).as_posix(),p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest()])
f=R/'file_manifest_sha256.csv';f.write_text(b.getvalue());files.append(f);s=R/'SHA256SUMS.txt';s.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in sorted(files)));files.append(s)
if '--zip' in sys.argv:
 z=R.parent/(R.name+'.zip')
 with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
  for p in sorted(files):archive.write(p,R.name+'/'+p.relative_to(R).as_posix())
 print('Built',z.name,len(files),'files',z.stat().st_size,'bytes')
