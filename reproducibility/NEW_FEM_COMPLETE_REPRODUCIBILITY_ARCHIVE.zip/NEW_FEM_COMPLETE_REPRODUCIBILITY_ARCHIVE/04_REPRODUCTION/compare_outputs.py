from pathlib import Path
import json
from PIL import Image,ImageChops,ImageStat
R=Path(__file__).resolve().parents[1];W=R/'04_REPRODUCTION/workspace';O=R/'06_VALIDATION/reproduction_test';changes=[];datasets=[]
skip={'summary','environment','run_all_manifest','abstract_audit','stale_tokens','unverified_numbers','coupling_provenance_check'}
for p in sorted((R/'03_DATA/results').glob('*.json')):
 if p.stem in skip:continue
 q=W/'results'/p.name
 if not q.exists():datasets.append({'dataset':p.name,'status':'MISSING'});continue
 differences=[];structure=[];counts=[0]
 def compare(a,b,path='$'):
  if isinstance(a,bool) or isinstance(b,bool):
   if a!=b:structure.append({'path':path,'baseline':a,'current':b})
  elif isinstance(a,(float,int)) and isinstance(b,(float,int)):
   counts[0]+=1
   if a!=b:d=abs(b-a);differences.append({'path':path,'baseline':a,'current':b,'absolute':d,'relative':d/abs(a) if a else None})
  elif isinstance(a,dict) and isinstance(b,dict):
   for k in sorted(a.keys()|b.keys()):
    if k not in a or k not in b:structure.append({'path':path+'.'+k,'status':'key missing on one side'})
    else:compare(a[k],b[k],path+'.'+k)
  elif isinstance(a,list) and isinstance(b,list):
   if len(a)!=len(b):structure.append({'path':path,'baseline_length':len(a),'current_length':len(b)})
   for i,(x,y) in enumerate(zip(a,b)):compare(x,y,f'{path}[{i}]')
 compare(json.loads(p.read_text()),json.loads(q.read_text()));datasets.append({'dataset':p.name,'status':'EXACT NUMERIC MATCH' if not differences and not structure else 'DIFFERENCES RECORDED','numeric_values':counts[0],'numeric_differences':len(differences),'max_absolute':max((x['absolute'] for x in differences),default=0),'max_relative':max((x['relative'] for x in differences if x['relative'] is not None),default=0),'structural_differences':structure});changes += [{'dataset':p.name,**x} for x in differences]
figures=[]
for p in sorted((R/'02_OVERLEAF/figures').glob('*.png')):
 q=W/'Paper_12/figures'/p.name
 if not q.exists():figures.append({'figure':p.name,'status':'MISSING'});continue
 a=Image.open(p).convert('RGB');b=Image.open(q).convert('RGB')
 if a.size!=b.size:figures.append({'figure':p.name,'status':'SIZE DIFFERENCE'});continue
 d=ImageChops.difference(a,b);figures.append({'figure':p.name,'status':'EXACT PIXEL MATCH' if d.getbbox() is None else 'PIXEL DIFFERENCE','size':a.size,'rms_RGB':ImageStat.Stat(d).rms})
s=json.loads((W/'results/summary.json').read_text());ok=s['all_pass'] and s['n_pass']==s['n_total']==70;missing=any(x['status']=='MISSING' for x in datasets+figures);status='FAIL' if not ok or missing else ('PASS WITH NUMERICAL DIFFERENCE' if changes or any(x.get('structural_differences') for x in datasets) else 'PASS')
out={'program_status':status,'overall':'PARTIAL: manuscript NOT COMPILED','acceptance':'Original70 Boolean criteria, no new global tolerance. Differences diagnostic; historical sensitivity arrays may pair differing stacks by index, not like-for-like physics. Runtime differences are metadata. PDF bytes not physically graded.','datasets':datasets,'figures':figures,'n_pass':s['n_pass'],'n_total':s['n_total']};(O/'output_comparison.json').write_text(json.dumps(out,indent=2));(O/'numeric_differences.json').write_text(json.dumps(changes,indent=2));print(status,'70-gate result',s['n_pass'],'PNG exact',sum(x['status']=='EXACT PIXEL MATCH' for x in figures),'/12','numeric differences',len(changes));raise SystemExit(not ok or missing)
