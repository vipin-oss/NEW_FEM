"""Static dependency checks do NOT compile or validate physics/DOI metadata."""
from pathlib import Path
import json,re,ast,shutil
R=Path(__file__).resolve().parents[1];P=R/'02_OVERLEAF';seen=set();inputs=[];issues=[]
def expand(p):
 if p in seen:return ''
 seen.add(p);s=re.sub(r'(?<!\\)%[^\n]*','',p.read_text())
 def inc(m):
  q=P/m.group(1)
  if not q.suffix:q=q.with_suffix('.tex')
  inputs.append({'source':p.relative_to(R).as_posix(),'target':q.relative_to(R).as_posix(),'exists':q.exists()})
  if not q.exists():issues.append('Missing input '+q.relative_to(R).as_posix());return ''
  return expand(q)
 return re.sub(r'\\(?:input|include)\{([^}]+)\}',inc,s)
body=expand(P/'main.tex');labels=re.findall(r'\\label\{([^}]+)\}',body);refs=set(re.findall(r'\\(?:ref|eqref|pageref|autoref)\{([^}]+)\}',body));cites=set()
for s in re.findall(r'\\cite\w*\*?(?:\[[^]]*\])*\{([^}]+)\}',body):cites.update(x.strip() for x in s.split(','))
keys=set(re.findall(r'^@\w+\s*\{\s*([^,]+),',(P/'references.bib').read_text(),re.M))
missing_refs=sorted(refs-set(labels));missing_cites=sorted(cites-keys);duplicates=[x for x in set(labels) if labels.count(x)>1];issues+=missing_refs+missing_cites+duplicates
graphics=[]
for name in re.findall(r'\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}',body):
 choices=[P/name,P/'figures'/name]
 if not Path(name).suffix:choices += [p.with_suffix(s) for p in list(choices) for s in ['.pdf','.png','.jpg']]
 q=next((p for p in choices if p.is_file()),None);graphics.append({'requested':name,'resolved':q.relative_to(R).as_posix() if q else None})
 if not q:issues.append('Missing graphic '+name)
for kind,ext in [('documentclass','.cls'),('bibliographystyle','.bst')]:
 for name in re.findall(r'\\'+kind+r'(?:\[[^]]*\])?\{([^}]+)\}',body):
  if not (P/(name+ext)).exists():issues.append('Missing '+name+ext)
syntax=[];absolute=[];secrets=[]
for p in R.rglob('*'):
 if not p.is_file() or any(x in p.relative_to(R).parts for x in ['workspace','__pycache__','.venv']):continue
 if p.suffix in ['.py','.md','.json','.txt','.csv','.log','.tex','.bib','.sh']:
  s=p.read_text(errors='replace')
  if re.search(r'/(?:home|tmp)/[^\s\"\']+',s):absolute.append(p.relative_to(R).as_posix())
  if re.search(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|AKIA[0-9A-Z]{16}',s):secrets.append(p.relative_to(R).as_posix())
  if p.suffix=='.py':
   try:ast.parse(s);syntax.append(p.relative_to(R).as_posix())
   except SyntaxError:issues.append('Python syntax '+p.relative_to(R).as_posix())
report={'status':'PASS' if not issues else 'FAIL','scope':'Static source/path/key audit, NOT compile/DOI/physical validation','inputs':inputs,'graphics':graphics,'cited_keys':len(cites),'bib_keys':len(keys),'missing_refs':missing_refs,'missing_cites':missing_cites,'duplicate_labels':duplicates,'uncited_keys':sorted(keys-cites),'issues':issues,'tex_tools':{x:bool(shutil.which(x)) for x in ['pdflatex','bibtex','latexmk','tectonic']}}
(R/'06_VALIDATION/manuscript_dependency_audit.json').write_text(json.dumps(report,indent=2))
static={'status':'PASS' if not issues and not absolute and not secrets else 'FAIL','Python_sources_parsed':syntax,'absolute_local_path_files':absolute,'private_key_token_pattern_files':secrets,'issues':issues,'privacy_limit':'Pattern scan is not legal/confidentiality certification. No Git config, venv/cache/builds shipped. Binary embedded paths not assessed.'}
(R/'06_VALIDATION/archive_static_audit.json').write_text(json.dumps(static,indent=2));print('Static manuscript',report['status'],'graphics',len(graphics),'cites',len(cites),'/',len(keys));print('Archive',static['status'],'absolute paths',absolute)
raise SystemExit(static['status']!='PASS')
