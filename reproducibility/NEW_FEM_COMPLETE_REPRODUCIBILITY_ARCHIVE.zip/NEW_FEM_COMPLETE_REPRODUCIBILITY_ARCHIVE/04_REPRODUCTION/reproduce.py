from pathlib import Path
import os,sys,subprocess,json,time
R=Path(__file__).resolve().parents[1];w=R/'04_REPRODUCTION/workspace';o=R/'06_VALIDATION/reproduction_test';o.mkdir(exist_ok=True)
if not w.exists():raise SystemExit('Run prepare.py first')
e=dict(os.environ)
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:e[k]='1'
e.update(PYTHONHASHSEED='0',MPLBACKEND='Agg',PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1')
records=[]
for s in ['run_demos.py','run_all.py','check_paper_numbers.py','check_float_order.py','check_paper_structure.py']:
 print('RUN',s,flush=True);t=time.monotonic()
 with (o/(s+'.log')).open('w') as log:p=subprocess.run([sys.executable,'python/'+s],cwd=w,env=e,stdout=log,stderr=subprocess.STDOUT)
 records.append({'command':['python3','python/'+s],'cwd':'04_REPRODUCTION/workspace','exit_code':p.returncode,'elapsed_seconds':time.monotonic()-t});(o/'execution.json').write_text(json.dumps(records,indent=2));print('EXIT',s,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
