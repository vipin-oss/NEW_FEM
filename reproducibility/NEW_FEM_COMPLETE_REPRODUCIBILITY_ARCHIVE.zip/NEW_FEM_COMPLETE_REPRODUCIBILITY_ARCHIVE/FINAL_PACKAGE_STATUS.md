# Final package status

**Overall: PARTIAL.** Numerical reproduction completed; manuscript compilation
and a reviewed paper PDF are NOT AVAILABLE. Do not represent static dependency
checks as a successful TeX build or the archive as submission-ready.

| Component | Status | Evidence |
|---|---|---|
| Install/program | PASS WITH NUMERICAL DIFFERENCE | Fresh isolated venv, OFFLINE included wheels + complete lock |
| Numerical workflow | PASS | FULL run_all.py, no --reuse, **70/70 checks pass**, all script exits0 |
| Data | PASS for included numerical data | 33 supplied baseline JSON plus current generated JSON; no experimental raw data |
| Number audit | PASS | **96/96 claims agree**, 0 stale hits of23 |
| Figure regeneration | PASS | 12 PDF/PNG pairs regenerated; **12/12 exact PNG pixel matches** |
| Manuscript source paths/keys | PASS static only | 12 graphics,61 cited keys,68 bibliography entries, no missing active refs/inputs/cites |
| Manuscript PDF | NOT AVAILABLE | No final paper PDF supplied/generated; page count NOT MEASURED |
| Overleaf/TeX | PARTIAL / NOT COMPILED | Required local class/style supplied, external TeX unavailable; fatal errors cannot be ruled out |
| Regression/smoke tests | PASS | **10/10 unittest tests**; unaltered solver/material/70 gate expressions verified |
| Overall reproduction test | PARTIAL | Numerical PASS WITH NUMERICAL DIFFERENCE; compile component NOT REPRODUCED |

## Actual NEW test, not recovered old evidence

Reconstructed from verified source b1c43a146fb4577f660958e721007a7535c74437.
This is NOT byte-identical recovery of the earlier lost ZIP. Earlier raw logs
are NOT AVAILABLE and are not fabricated. Current execution logs/results are
new, genuinely executed records. Workspace starts EMPTY, demo bootstrap runs
before dependent readers, then full suite and final audits sequentially.
Full suite **784.0s**, wrapper total **878.5s**, hardware-dependent.
Exact versions, offline install, script-stage timings, differences and criteria
are retained. Historical alternate stacks/MATLAB were NOT reexecuted.

Portability corrections expose rather than hide cached-history assumptions:
page-budget missing-Git/calibration guard; gradient benchmark reads fresh V2
at original4-decimal precision, not absent prior summary; unused harness-count
summary reads removed from paper audit (same96 active rows/tolerances); report
list shadowing fixed; interpreter docstring example made portable. Exact patch
and preservation audit included. No scientific solver/material/70 gate change.

## Remaining blockers/recommended action

1. Install compatible full TeX Live or use Overleaf, run pdfLaTeX/BibTeX/
   pdfLaTeX/pdfLaTeX, retain logs and manually inspect pages, numbering,
   frontmatter/fonts/boxes. Resolve real errors without changing science.
   Add reviewed manuscript PDF. Static audit cannot certify compile freedom.
2. Supply true author/affiliation/email/journal/CRediT information and confirm
   funding. Existing placeholders/acknowledgements remain unchanged.
3. Verify primary material/benchmark/bibliographic metadata (author notes and
   reference_audit). Original FEM-5 material record/publisher raw data NOT
   AVAILABLE. Density, mu and relaxation remain assumed. No experimental validation.
4. Experimental observations, statistical noise/uncertainty calibration,
   FIM/CRLB/inverse identification and separate full nondimensionalization
   are NOT AVAILABLE / NOT IMPLEMENTED; no substitute data/formula invented.
5. MATLAB/other OS/CPU/Python/older-stack runs are NOT REPRODUCED. Wheels cover
   Linux x86_64 CPython3.11 only. Python/OS/TeX are external prerequisites.
   Project license and earlier pre-import history NOT DOCUMENTED/AVAILABLE;
   clear redistribution/resubmission rights. Third-party notices retained.
6. Existing model limits: linear small strain,2-D plane stress,scalar flexo,
   explicit memory placement and distinct coupling definitions; a/L<=.2 is
   ASSUMED, not validated. Follow KNOWN_LIMITATIONS and comparison interpretation.

Use numerical evidence now, but complete TeX/frontmatter/source/rights review
before claiming submission readiness. All payload SHA-256/ZIP integrity checks
must pass before publication; public asset is the permanent deliverable.
