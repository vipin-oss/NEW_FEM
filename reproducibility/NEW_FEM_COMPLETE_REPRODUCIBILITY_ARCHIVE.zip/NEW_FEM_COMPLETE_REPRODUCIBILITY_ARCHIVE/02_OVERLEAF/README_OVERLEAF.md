# Independent manuscript project

Upload this directory's CONTENTS to Overleaf; main document main.tex, pdfLaTeX
with BibTeX. Highlights.tex is a submission fragment, not a second main paper.
All active inputs/figures/bibliography are local. elsarticle.cls (3.4c,
2025/01/11) and elsarticle-num.bst are vendored from the pinned real upstream
revision with license/source provenance; their inclusion is NOT a compile test.

Required external TeX environment: compatible full TeX Live with fontenc,
inputenc, graphicx, amsmath, bm, amssymb, amsthm, mathrsfs, mathtools, multirow,
booktabs, siunitx, natbib, float, placeins, hyperref, class dependencies/fonts.
No TeX engine/packages are installed or bundled here. Exact installed TeX
versions are NOT AVAILABLE; cloud Overleaf compilation has NOT been performed.

From this directory:
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex

Status NOT COMPILED. No final manuscript PDF is supplied or generated. Static
paths/labels/citation checks cannot certify fatal-error freedom, frontmatter,
font compatibility, overfull boxes, page count or rendered numbering. Page
count NOT MEASURED; old notes about 31/35 pages are not current evidence.
Author/funding/CRediT placeholders and scientific content were NOT changed to
hide an error. Populate true frontmatter and resolve author-only source risks.
references.bib key existence does not establish DOI accuracy or scientific support.
