# Single canonical final-output index

Manuscript source, seven active tables and twelve final PDF/PNG figure pairs:
02_OVERLEAF (only one canonical copy). Manuscript PDF NOT AVAILABLE / NOT COMPILED.
Baseline numerical outputs: 03_DATA/results. Supplied validation reports:
06_VALIDATION/supplied_results, explicitly historical. New execution/result/
comparison evidence: 06_VALIDATION/reproduction_test. Source assets and archive
hashes do not substitute for a reviewed compiled paper or scientific clearance.
