# NEW_FEM complete reproducibility archive

Read FINAL_PACKAGE_STATUS.md FIRST. This is a reconstructed source/data package,
not recovery of the old ZIP bytes and not proof of manuscript compilation.
All available source/data and full provenance are provided; missing information
is explicitly NOT DOCUMENTED / NOT AVAILABLE. No scientific inputs are invented.

01_PROGRAM: Python authority, MATLAB mirror, tests/configuration/offline wheels.
02_OVERLEAF: ONE canonical active manuscript, tables, figures and local class/style.
03_DATA: immutable supplied numerical baseline, auxiliary demo plots, dictionary.
04_REPRODUCTION: workspace preparation, exact workflow, comparison/build/hash tools.
05_DERIVATIONS: existing equations verbatim and historical derivation notes.
06_VALIDATION: supplied evidence separated from current clean isolated test.
07_DOCUMENTATION: current model/numerics/provenance/change/limitations guides;
  history/ contains superseded editorial notes, not competing final papers.
08_FINAL_OUTPUTS: index linking canonical outputs, not duplicate copies.
09_ARCHIVE_METADATA: source/run/parameter/data/result/figure/reference manifests.

Start with 04_REPRODUCTION/REPRODUCE_FROM_SCRATCH.md. The portable prepare tool
reconstructs the original sibling python/, Paper_12/, results/ layout with no
symlinks. Do NOT directly run numerical programs from 01_PROGRAM: they expect
that sibling layout. Empty-results reproduction does not seed baseline data.

Verify before execution: python3 04_REPRODUCTION/verify_integrity.py.
SHA256SUMS hashes all payload including the CSV manifest, except itself.
The CSV omits itself and SHA256SUMS to avoid circular self-hashes.
The old Paper_12.zip and duplicate figures/caches/builds/credentials are omitted.
No project license was supplied; do not infer reuse or resubmission permission.
