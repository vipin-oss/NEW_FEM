# Result provenance

result_provenance.json maps every70 acceptance criterion: script → source inputs/
parameter/default catalog → exact workspace command → output → supplied expected
observation → unchanged Boolean tolerance. paper_claim_manifest maps each source
claim expression; loops expand to96 active rows. Every figure and active table
has a separate producer/source index. Data dictionary covers every33 baseline JSON.
Current test results/comparison are separate from supplied baselines and from
unavailable raw experimental data. No new uncertainty bound/DOI is invented.
