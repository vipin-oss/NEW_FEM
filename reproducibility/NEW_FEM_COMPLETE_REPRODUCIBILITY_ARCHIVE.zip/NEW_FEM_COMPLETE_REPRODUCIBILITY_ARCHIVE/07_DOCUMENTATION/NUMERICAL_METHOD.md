# Numerical method

mesh_rect uses rectangular C1 bicubic BFS displacement with eight mechanical
DOFs/node and bilinear potential with one electric DOF/node: 32+4 per element.
Physical derivative scaling, strain/gradient operators and default4x4 Gauss
quadrature are implemented in fem6_core.assemble/element_matrices. Mechanical
constraints and electric condensation are experiment-specific (see BC source).

modes diagonally scales S=diag(1/sqrt(abs(Kii))), solves generalized symmetric
pencil with dense eigh for n<=2600 else shift-invert eigsh sigma0 whichLM,
then mass-normalizes. Some static free-strip routes use lstsq rcond1e-11;
some coupling secular sums need ALL modes. Precision-sensitive near-canceling
eigenvalue differences must not be replaced by a truncated modal sum.

transient uses mass-normalized modes, projected Kd, full implicit L1 history
b_j=(j+1)^(1-alpha)-j^(1-alpha) with alpha1 special case, Newmark beta1/4,
gamma1/2, fixed step-matrix Cholesky solve. dt/modes depend on experiment;
there is no undocumented universal safe step. Newton pole solve max200,
abs(ds)<1e-14*abs(s), with continuation where required. Polynomial roots for
rational alpha provide an independent algebraic check.

Patch, inertia/symmetry, energy, mesh/time convergence, MAC and modal truncation
remain in original 70 checks. Exact criteria in criterion_expressions.json.
The source catalog records all defaults/overrides as expressions, not invented
runtime values. Existing dimensionless groups a/L,a2/h,omega*tau,alpha,k²,x
are retained; separate full nondimensionalization is NOT AVAILABLE.
