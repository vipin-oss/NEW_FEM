# Model description

Authoritative energy/governing/constitutive derivation: sec/02_formulation.tex;
particular/limiting cases: 03_particular_cases and 91_appendixA. Verbatim equations
are indexed in 05_DERIVATIONS. No new scientific equations/parameters are invented.

Small-strain u, potential phi, E=-grad(phi), strain/strain gradient enter elastic,
gradient, piezoelectric, dielectric and scalar flexoelectric enthalpy. Source
factors/signs are authoritative: gradient energy factor1/4 M*C gives stiffness
factor1/2 integral. Cuboid, planar ellipse and 3-D ellipsoid moments differ:
a_i²/3, a_i²/4, a_i²/5. Equal half-width is NOT equal second moment.

BaTiO3 C/e/kappa are attributed to Zgonik through a missing FEM-5 record;
density and mu are assumed. Plane-stress/plane-strain, poling and electrode pair
must be specified together. Mechanical BC include displacement/normal slope or
traction/double traction. Short grounds pair; open grounds one and floats the
other equipotential, zero-net-charge electrode. Condensation gives rank-one
K_oc=K_sc+d*d^T/beta. Modal coupling uses squared-frequency ratios; static
x/(1+x), x=d^T*K_sc^-1*d/beta is a distinct measure. Actual design-map bending
code is modal even where inherited docstring calls both columns mode-free:
this pre-existing wording inconsistency is documented, not silently fixed.

Memory solves M*x''+K*x+tau^alpha*Kd*D_Caputo^alpha*x=f, with Kd explicitly
K_eff or K_uu. They damp differently. F9 is unforced release of selected mode
scaled to10nm tip displacement, zero velocity. For alpha<1 the first-period
decrement conversion is descriptive, not exact exponential damping.
a/L<=0.2 is ASSUMED, not validated. Linear small strain, 2-D plane stress and
scalar flexoelectricity limit applicability. No thermal/nonlinear/FIM/CRLB/
calibrated statistical model is implemented or claimed.
