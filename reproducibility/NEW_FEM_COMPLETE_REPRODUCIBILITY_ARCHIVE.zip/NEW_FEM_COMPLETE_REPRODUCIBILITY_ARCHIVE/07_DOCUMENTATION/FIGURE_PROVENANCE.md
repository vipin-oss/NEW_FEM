# Every manuscript figure — reproducible provenance

Commands run in prepared workspace AFTER the full workflow. Asset IDs are stable filenames, not compiled figure numbers.

| Asset (PDF + PNG) | Producer/function | Inputs | Redraw command | Expected/tolerance |
|---|---|---|---|---|
| F11_designmap.pdf | 01_PROGRAM/python/run_design_map.py: main/draw | design_map.json; 64 FE combinations | `python3 python/run_design_map.py --replot` | Original 70 gates; no new visual tolerance invented |
| F1_geometry.pdf | 01_PROGRAM/python/run_paper_figures.py: fig_p1_geometry | schematic; caption geometry | `python3 python/run_paper_figures.py F1` | Original 70 gates; no new visual tolerance invented |
| F2_convergence.pdf | 01_PROGRAM/python/run_paper_figures.py: fig_p11_convergence | on-demand FE mesh convergence | `python3 python/run_paper_figures.py F2` | Original 70 gates; no new visual tolerance invented |
| F3_fields.pdf | 01_PROGRAM/python/run_paper_figures.py: fig_p12_fields | on-demand coupled mode/fields | `python3 python/run_paper_figures.py F3` | Original 70 gates; no new visual tolerance invented |
| F4_orientation.pdf | 01_PROGRAM/python/run_paper_figures.py: fig_orientation | paper_figures_data.json polar/symmetry; polar_sweep | `python3 python/run_paper_figures.py F4` | Original 70 gates; no new visual tolerance invented |
| F5_design.pdf | 01_PROGRAM/python/run_paper_figures.py: fig_p14_design_space | paper_figures_data.json polar | `python3 python/run_paper_figures.py F5` | Original 70 gates; no new visual tolerance invented |
| F6_damping.pdf | 01_PROGRAM/python/run_paper_figures.py: fig_damping | on-demand complex pole/continuation | `python3 python/run_paper_figures.py F6` | Original 70 gates; no new visual tolerance invented |
| F7_window.pdf | 01_PROGRAM/python/run_paper_figures.py: fig_window | on-demand static steel window/size solves | `python3 python/run_paper_figures.py F7` | Original 70 gates; no new visual tolerance invented |
| F8_thickness.pdf | 01_PROGRAM/python/run_paper_figures.py: fig_p7_thickness | demo.json flexo_thickness + coupling_check.json closed_form | `python3 python/run_paper_figures.py F8` | Original 70 gates; no new visual tolerance invented |
| F9_ringdown.pdf | 01_PROGRAM/python/run_paper_figures.py: fig_p6_waterfall | on-demand F9 modal L1 histories; paper_figures_data notes.P6 | `python3 python/run_paper_figures.py F9` | Original 70 gates; no new visual tolerance invented |
| FB1_tracking.pdf | 01_PROGRAM/python/run_paper_figures.py: fig_p8_mac | mode_tracking.json | `python3 python/run_paper_figures.py FB1` | Original 70 gates; no new visual tolerance invented |
| FB2_modes.pdf | 01_PROGRAM/python/run_paper_figures.py: fig_p4_modeshape | on-demand mode solves | `python3 python/run_paper_figures.py FB2` | Original 70 gates; no new visual tolerance invented |
