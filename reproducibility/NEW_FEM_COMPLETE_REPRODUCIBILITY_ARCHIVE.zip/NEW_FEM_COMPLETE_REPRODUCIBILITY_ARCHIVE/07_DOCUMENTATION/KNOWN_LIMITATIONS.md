# Known limitations

No TeX engine/cloud compile or manuscript PDF; source paths cannot certify fatal
error freedom, frontmatter/fonts/overfull boxes/page count. Complete TeX Live is
an external prerequisite. Author/journal/email/CRediT/funding confirmation pending.
Primary-source bibliography/material/benchmark uncertainty retained. rho, mu and
relaxation assumed; FEM-5 original record and publisher raw data NOT AVAILABLE.
a/L<=.2 assumed, not validated; 2-D linear plane stress/scalar flexoelectric law.
Static/modal coupling and K_eff/K_uu memory differ. Design-map inherited wording
calls bending mode-free but actual code is modal; documented inconsistency.
No experimental calibration, statistical uncertainty, FIM/CRLB, thermal/nonlinear
solver or separate complete nondimensionalization. Never fabricated to fill gaps.
Thin-strip differences of eigenvalues are stack-sensitive; quoted digits not
physical measurement accuracy. eigsh has no explicit v0 seed guarantee.
MATLAB and alternative OS/Python/CPU stacks are NOT REPRODUCED; wheels only Linux
x86_64 CPython3.11. No interpreter/OS/TeX bundled. Project license NOT DOCUMENTED.
Full field histories may require rerunning functions; not falsely supplied.
This reconstructed archive is not byte-identical recovery of former ZIP; old
raw test logs unavailable. Current test logs are genuine new executions.
