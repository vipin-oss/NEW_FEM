# Active table provenance

Hand-curated TeX is not falsely called automatically generated. Exact numeric
source/precision is validated by the96-claim audit; other legacy table files are
unprinted and regenerated only as archive outputs.

- table_application.tex: make_paper_table.py application_table → application_table.json
- table_convergence.tex: make_appendix_tables.py table_convergence → fresh extensional FE solves at12x2/24x2/36x2/48x4
- table_memory.tex: hand-curated; memory_variants.json, dt_study and paper number audit
- table_params.tex: hand-curated; materials.py and experiment inputs (assumed vs sourced distinguished)
- table_thickness.tex: make_appendix_tables.py table_thickness → demo.json flexo_thickness
- table_verification.tex: hand-curated seven-row selection from verification/closed-form/independent-check JSON
- table_worked.tex: hand-curated worked values; worked_example.py/JSON and paper audit
