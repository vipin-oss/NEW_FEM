# Project overview

NEW_FEM/FEM-6: fractional-memory piezoelectric–flexoelectric strain-gradient
solids with a rectangular averaging window, C1 Bogner–Fox–Schmit elements.
Python is numerical authority; MATLAB mirror is NOT EXECUTED. Source covers
static/gradient benchmarks, electrical coupling, modes, orientation/window/
thickness sweeps, fractional poles/ringdown and sensitivity. Not an experimentally
identified constitutive record, thermal solver or inverse/FIM pipeline.

All 200 supplied source files were read/inventoried and match fetched snapshot
b1c43a146fb4577f660958e721007a7535c74437. Current local HEAD/index is not used to
invent a scientific source version; exact file hashes and fetched history are
recorded. Earlier pre-import history is NOT AVAILABLE. Historical notes may
conflict with current code; they are not competing final versions.
This ZIP is freshly reconstructed, not the original lost archive bytes. Earlier
raw package-test logs are NOT AVAILABLE. Newly executed evidence is separate.
