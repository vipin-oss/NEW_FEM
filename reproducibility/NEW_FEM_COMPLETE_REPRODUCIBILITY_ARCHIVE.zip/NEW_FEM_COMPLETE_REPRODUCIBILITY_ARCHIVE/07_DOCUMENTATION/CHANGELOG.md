# Changelog

Reconstructed package: inventory/read all200 supplied source files, hash/match
fetched b1c43a1 snapshot, select canonical active manuscript, omit old nested ZIP,
duplicate assets/caches and unprinted generated tables; retain all generators.
Add complete locked/offline dependencies, parameter/data/result/figure manifests,
source/default/equation indices, run order, tests and integrity tools.
Five explicit package-only corrections: missing historical Git/calibration guard;
read fresh verification V2 rather than absent prior summary; remove dead unused
summary reads from paper audit; fix report-list/L1 variable shadowing; replace
nonfunctional absolute interpreter example. Exact patch and original hashes
included. Solver/material/numeric verification functions and70 criteria unchanged.
No scientific source/author placeholders changed to hide TeX errors.

New independent clean-test evidence is recorded; old package/failed-attempt raw
logs are NOT AVAILABLE after the prior lost archive. Earlier conversation reports
are not substituted for raw evidence or claimed bytewise archive recovery.
Available branch history is exported by real Git commands. Earlier pre-import
scientific ancestry is NOT AVAILABLE; historical editorial notes are narratives,
not unverified invented commit ancestry. Current canonical source supersedes them.
