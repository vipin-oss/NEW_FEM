# Comparison interpretation

PASS WITH NUMERICAL DIFFERENCE is not bytewise identity. Every original70 gate
and all96 manuscript claims pass. Numeric differences are listed with exact paths,
values and absolute/relative deltas; no new common tolerance was invented.
verification.runtime_s is timing metadata, not physics. Historical sensitivity
baseline aggregates24 path rows over4 recorded environments; an empty-results
single-stack run emits6 rows. Ordinal list pairings of different environments
are not like-for-like physical-error estimates. Old stacks were retained but
NOT reexecuted. Some optional old plot-display metadata keys may not be emitted;
baseline values remain available and actual plot settings remain in source.
Independent benchmark last-bit frequency differences are graded by unchanged
criteria. All PNG comparisons are explicit; PDF creation-date/font bytes are
not treated as physical errors. No manuscript PDF/TeX compile is represented.
