# Numbers in the abstract, the conclusion, the Highlights and the captions

46 numbers checked, 46 traced, 0 untraced.

| place | number | found in |
|---|---|---|
| main.tex abstract | `0.09` | elsewhere in the manuscript |
| main.tex abstract | `0.450` | elsewhere in the manuscript |
| main.tex abstract | `0.5581` | elsewhere in the manuscript |
| main.tex abstract | `0.5608` | elsewhere in the manuscript |
| main.tex abstract | `1.0\times10^{-2}` | elsewhere in the manuscript |
| main.tex abstract | `1.9\times10^{-2}` | elsewhere in the manuscript |
| main.tex abstract | `200` | elsewhere in the manuscript |
| main.tex abstract | `3.6\times10^{-6}` | elsewhere in the manuscript |
| main.tex abstract | `6.5\times10^{-6}` | elsewhere in the manuscript |
| 09_conclusions.tex | `0.02` | elsewhere in the manuscript |
| 09_conclusions.tex | `0.063` | elsewhere in the manuscript |
| 09_conclusions.tex | `0.0675` | elsewhere in the manuscript |
| 09_conclusions.tex | `0.085` | elsewhere in the manuscript |
| 09_conclusions.tex | `0.09` | elsewhere in the manuscript |
| 09_conclusions.tex | `0.104` | elsewhere in the manuscript |
| 09_conclusions.tex | `0.1141` | elsewhere in the manuscript |
| 09_conclusions.tex | `0.15003` | elsewhere in the manuscript |
| 09_conclusions.tex | `0.450` | elsewhere in the manuscript |
| 09_conclusions.tex | `0.4580` | elsewhere in the manuscript |
| 09_conclusions.tex | `0.5581` | elsewhere in the manuscript |
| 09_conclusions.tex | `0.5608` | elsewhere in the manuscript |
| 09_conclusions.tex | `1.0\times10^{-2}` | elsewhere in the manuscript |
| 09_conclusions.tex | `3.1\times10^{-4}` | elsewhere in the manuscript |
| 09_conclusions.tex | `3.6\times10^{-6}` | elsewhere in the manuscript |
| 09_conclusions.tex | `6.2\times10^{-4}` | elsewhere in the manuscript |
| 09_conclusions.tex | `7.5\times10^{-3}` | elsewhere in the manuscript |
| Highlights.tex | `0.450` | elsewhere in the manuscript |
| sec/02_formulation.tex | `200` | elsewhere in the manuscript |
| sec/07_results.tex | `200` | elsewhere in the manuscript |
| sec/07_results.tex | `-18.7` | elsewhere in the manuscript |
| sec/07_results.tex | `6.727` | elsewhere in the manuscript |
| sec/07_results.tex | `0.02` | elsewhere in the manuscript |
| sec/07_results.tex | `1.35` | elsewhere in the manuscript |
| sec/07_results.tex | `6.73` | elsewhere in the manuscript |
| sec/07_results.tex | `0.05` | elsewhere in the manuscript |
| sec/07_results.tex | `0.09` | elsewhere in the manuscript |
| sec/07_results.tex | `3.1\times10^{-4}` | elsewhere in the manuscript |
| sec/07_results.tex | `7.5\times10^{-3}` | elsewhere in the manuscript |
| sec/07_results.tex | `0.01` | results archive |
| sec/07_results.tex | `200` | elsewhere in the manuscript |
| sec/07_results.tex | `0.13` | elsewhere in the manuscript |
| sec/07_results.tex | `0.35` | elsewhere in the manuscript |
| sec/07_results.tex | `4000` | results archive |
| sec/07_results.tex | `6.727` | elsewhere in the manuscript |
| sec/07_results.tex | `200` | elsewhere in the manuscript |
| sec/92_appendixB.tex | `200` | elsewhere in the manuscript |
