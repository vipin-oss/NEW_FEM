# Platform sensitivity of the h = 1 um flexoelectric coupling

One model (48$\times4$, poling $y$, electrodes on the long faces, $\mu=10^{-6}$ C/m), five eigensolver paths, three numeric stacks.  The deviations are relative to the **midpoint** of the equivalent rows, never to the running stack, so the same table is produced on every machine.

**h = 1 um: spread 0.059 %; h = 10 um: spread 5.743e-07 %.**  The growth factor ranges 23.92-23.93.

| stack | path | $k^2$ (h = 1 um) | dev [%] | $k^2$ (h = 10 um) | dev [%] | growth |
|---|---|---|---|---|---|---|
| py3.11.2 np2.4.6 sp1.17.1 | dense eigh, scaled | 4.17329e-03 | +0.030 | 1.74373e-04 | +2.87e-07 | 23.93 |
| py3.11.2 np2.4.6 sp1.17.1 | dense eigh, unscaled | 4.17325e-03 | +0.029 | 1.74373e-04 | +1.23e-07 | 23.93 |
| py3.11.2 np2.4.6 sp1.17.1 | QZ (eig, general) | 4.17288e-03 | +0.020 | 1.74373e-04 | -2.87e-07 | 23.93 |
| py3.11.2 np2.4.6 sp1.17.1 | numpy eig, all modes | 4.17082e-03 | -0.030 | 1.74373e-04 | +2.16e-07 | 23.92 |
| py3.11.2 np2.4.6 sp1.17.1 | dense eigh, 12 modes | 7.66536e-03 | +83.731 | 3.03405e-04 | +7.40e+01 | 25.26 |
| py3.11.2 np2.4.6 sp1.17.1 | sparse eigsh, 12 modes | 7.67534e-03 | +83.970 | 3.03404e-04 | +7.40e+01 | 25.30 |

The h = 1 um value is the least reproducible number in the paper: it is a small difference of two nearly equal eigenvalues of a pencil with condition $\sim10^{12}$, so it inherits the eigenvector accuracy of the stack.  Two significant digits (4.2e-3, growth 24) are stable across every row of this table; the fourth digit is not, which is why the manuscript quotes two.

