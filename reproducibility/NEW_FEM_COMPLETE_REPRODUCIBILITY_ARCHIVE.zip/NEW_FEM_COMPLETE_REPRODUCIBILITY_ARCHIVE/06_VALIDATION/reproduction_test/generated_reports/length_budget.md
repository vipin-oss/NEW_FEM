# Page budget (estimate, not a measurement)

No full TeX Live here; no compiled page count is measured by this script. Text width 481.9 pt, text height 714.3 pt, 100 characters per line, 12 pt per line; figure heights from each PDF's MediaBox and its `width=` option, table heights from row counts.

Historical calibration NOT AVAILABLE; compiled pages NOT MEASURED.

| block | amount | pt | pages |
|---|---|---|---|
| body figures | 12 | 3264 | 4.57 |
| body tables | 5 | 693 | 0.97 |
| body prose and display maths | 15046 words | 13515 | 18.92 |
| appendix figures | 0 | 0 | 0.00 |
| appendix tables | 2 | 270 | 0.38 |
| appendix prose |  | 811 | 1.13 |
| reference list | 68 entries | 2543 | 3.56 |
| **sum** | | **21096** | **29.53** |

## Where the body stands

| | body content | pages of area |
|---|---|---|
| this revision | 17472 pt | 24.46 |

## From area to pages

## Biggest items now

| float | pt | pages | in |
|---|---|---|---|
| `fig:orientation` (figure) | 435 | 0.61 | body |
| `fig:fields` (figure) | 307 | 0.43 | body |
| `fig:modes` (figure) | 281 | 0.39 | body |
| `fig:modetrack` (figure) | 264 | 0.37 | body |
| `fig:ringdown` (figure) | 263 | 0.37 | body |
| `fig:convergence` (figure) | 262 | 0.37 | body |
| `fig:damping` (figure) | 261 | 0.37 | body |
| `fig:geometry` (figure) | 252 | 0.35 | body |
| `fig:design` (figure) | 243 | 0.34 | body |
| `fig:window` (figure) | 235 | 0.33 | body |

| section | words of source | pages of area |
|---|---|---|
| Introduction | 1641 | 1.95 |
| Formulation | 2506 | 3.81 |
| Particular cases | 858 | 1.06 |
| Boundary conditions | 918 | 1.24 |
| Finite element formulation | 1720 | 2.40 |
| Validation and limiting cases | 1585 | 2.01 |
| Numerical results and discussion | 4445 | 4.66 |
| Parameter identification and limitations | 457 | 0.69 |
| Conclusions | 447 | 0.51 |
| CRediT authorship contribution statement | 68 | 0.09 |
| Declaration of competing interest | 30 | 0.03 |
| Data availability | 44 | 0.06 |
| Acknowledgements | 20 | 0.03 |


The estimate carries about one page of error and is not a substitute for `pdflatex`.
