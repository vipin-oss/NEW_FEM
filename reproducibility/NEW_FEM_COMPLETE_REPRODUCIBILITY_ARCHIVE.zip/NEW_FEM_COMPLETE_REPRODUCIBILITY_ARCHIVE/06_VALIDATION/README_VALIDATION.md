# Evidence hierarchy

supplied_results: source-snapshot reports, may contain superseded counts/layout.
reproduction_test: actual NEW isolated offline test, empty results, no --reuse.
Earlier lost archive raw logs are NOT AVAILABLE and are not reconstructed as
fake execution evidence. Historical failed dependencies are described by exact
portability patch, regression tests and reconstruction note, not forged logs.
criteria/protocol: existing acceptance conditions/source attribution limits.
manuscript_dependency_audit/archive_static_audit: file/syntax/path/key checks,
NOT TeX compilation, primary reference verification or experimental validation.
Full current test status must come from actual exit records/summary, not notes.
