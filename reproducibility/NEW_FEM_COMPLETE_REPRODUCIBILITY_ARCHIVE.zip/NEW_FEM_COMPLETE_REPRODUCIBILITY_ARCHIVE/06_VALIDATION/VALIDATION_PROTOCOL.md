# Validation routes, sources and limits

Exact benchmark quantities/observations/requirements are in VALIDATION_CRITERIA.md
and all70 Boolean expressions in criterion_expressions.json. Actual test results
are regenerated separately; supplied observations are not relabeled new evidence.

FEM-1 static: run_verification.py v2_fem1_benchmark/u_right. Steel rectangle
1x.2m, E2e11Pa, nu.3, rho7850, left clamped, right traction1e6Pa, other edges
free; 20x4, ellipsoid l/L=.2 compared with supplied4.23µm (2% gate). Exact mesh
sweep/refinement in parameter manifest. Supplied bibliography key fem1 DOI
10.1016/j.finel.2026.104681. Metadata/publisher raw data NOT independently
verified/retrieved; original benchmark dataset NOT AVAILABLE.

Euler–Bernnoulli/Timoshenko: independent_checks frequency functions, e=mu=0,
zero gradient, 200x10µm strip, free-edge beam modulus, rho6020, CF betaL1.8751,
CC4.7300, nx48/96/128 ny4. Expected/observed errors in independent_checks.json.
Textbook DOI for these equations NOT DOCUMENTED; do not invent one.
Constitutive coupling: derive_k2_closed_form/run_coupling_check; free/clamped,
2-D stress/strain/3-D reductions distinct. Zgonik attribution via missing FEM-5
record is not primary-source verification. Full C/e/kappa are recorded.

Fractional damping: Newton vs polynomial roots for rational alpha, alpha1 exact
Kelvin–Voigt zeta=omega*tau/2. Uniform-curvature flexoelectric charge/energy:
F3 prescribed quadratic field, x=12mu²/(E_b*h²*kappa33), k²=x/(1+x); exact
independent source derivation and all parameter rows retained. These are
algebraic checks, not experimental BaTiO3 validation.
Patch/gradient/coupled reciprocity/inertia/L1/time/mesh/truncation/MAC checks
retain scripts/data/gates even when no longer printed in Appendix B.

Experimental verification, external original raw datasets, MATLAB execution,
FIM/CRLB/identified noise models and old alternative-stack reruns are
NOT REPRODUCED / NOT AVAILABLE. Numerical-stack sensitivity is not confidence
intervals. See supplied reference_audit and author notes for bibliographic gaps.
