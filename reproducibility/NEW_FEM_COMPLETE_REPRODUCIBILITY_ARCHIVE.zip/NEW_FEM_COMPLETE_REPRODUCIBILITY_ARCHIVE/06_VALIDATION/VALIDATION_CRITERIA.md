# Validation criteria — supplied baseline distinguished from new test

Exact Boolean expressions are preserved in criterion_expressions.json.

| ID | Quantity | Supplied observation | Existing requirement |
|---|---|---|---|
| V1a | patch energy, rel. error | 4.44e-16 | < 1e-12 |
| V1b | gradient energy under constant strain | 1.06e-12 | < 1e-9 |
| V1c | K_g(ellipsoid) vs FEM-1 (l^2/10) | 3.40e-16 | < 1e-12 |
| V1d | K_g(cuboid)/K_g(ellipsoid), equal a | 1.666667 | = 5/3 = 1.666667 |
| V1e | cuboid vs ellipsoid at equal M | 0.00e+00 | = 0 (< 1e-12) |
| V2 | FEM-1 benchmark, u_R at l/L = 0.20 | 4.2339 um | within 2 % of 4.23 um (paper) |
| V3 | observed mesh order | 1.68 | > 1.5 |
| V4a | bending mode k_eff^2 (piezo only) | 4.08e-09 | < 1e-6 (no net charge in bending) |
| V4b | length-extensional max k_eff^2 | 0.3991 | > 0.35 |
| V5a | alpha = 1 vs closed-form KV, order | 0.99 | > 0.9 |
| V5e | L1 at alpha = 1, order from the N/2N/4N sequence | 0.97 (zeta 0.150111 -> 0.150029) | 0.9 - 1.1 |
| V5b | harmonic |H|, worst deviation | 0.37 % | < 2 % |
| V5c | tau -> 0 residual | 2.08e-09 | < 1e-6 |
| V5d | delivered L1 stencil vs analytic |H| | 0.52 % | < 1 % |
| V6a | static truncation, 24 modes | 3.19e-02 | < 5e-2 |
| V6b | static truncation, monotone decreasing | yes | monotone |
| V7 | equal-M cuboid vs ellipsoid, max rel. diff | 0.00e+00 | < 1e-12 |
| F1 | flexo patch test, mu = 0 | 0.00e+00 V | = 0 |
| F2 | flexo patch test vs mu*kappa*h/kappa33 | 1.0000000000 | = 1 (1e-10) |
| F3 | flexo linearity V(2mu)/V(mu) | 2.0000000000 | = 2 |
| F4 | bending k_eff^2 with flexo (mu=1e-6) | 1.25e-04 | > 1e-5 |
| M1 | kappa11/kappa33 | 39.3 | > 30 (real crystal, was 1.2) |
| S1a | zeta(K_eff, alpha=1) vs omega*tau/2 | 0.15003 vs 0.15000 | within 2 % |
| S1b | zeta(K_uu)/zeta(K_eff) at alpha=1 | 0.450 | in (0, 1) -- the choice matters |
| S2 | KV/Zener modulus at omega*tau = 1, alpha = 1 | 1.345 | > 1.3 (KV unbounded) |
| C1 | FEM k^2 (unconstrained strip) vs 2-D closed form e^T C^-1 e/kappa | 0.56079 vs 0.56079 | rel. diff < 1e-3 |
| C2 | 2-D model vs 3-D free bar (plane-stress reduction) | 2.83 % | < 5 % (documented modeling gap) |
| C3 | FEM k^2, clamped strip, 96x4 vs 48x4 | 0.55992 vs 0.55957 | rel. diff < 1e-3 |
| C4 | FEM k^2, clamped strip, 24x2 vs 48x4 | 0.13 % | < 0.5 % (coarse mesh) |
| K1 | lowest MAC of mode 1 vs the h = 10 um shape (4 thicknesses) | 0.99919 | > 0.999 |
| K2 | worst f2/f1 over the thickness sweep (mode off-diagonal) | 2.2e-06, f2/f1 >= 6.21 | off-diag < 1e-5, ratio > 6 |
| D1 | closed form e'C^-1 e/kappa vs FEM coupling (free strip) | 0.56079 vs 0.56079 | rel. diff < 1e-3 |
| D2 | the superseded series is exactly k^2/(1+k^2) of the new one | 3.5e-06 | < 1e-5 (same formula applied twice) |
| I1 | clamped-free f1, FEM 48x4 vs Euler-Bernoulli closed form | 144.6 vs 143.8 kHz | |err| < 1 % (+0.54 %) |
| I2 | clamped-clamped f1, FEM 48x4 vs Euler-Bernoulli closed form | 919.2 vs 915.0 kHz | |err| < 1 % (+0.46 %) |
| I3 | clamped-free f1 at 128x4 vs Euler-Bernoulli (mesh refinement) | 144.08 kHz | |err| < 0.5 % (+0.20 %) |
| I4 | zeta from Newton pole vs polynomial roots (10 alpha, 2 omega*tau) | 1.4e-10 | < 1e-8 |
| I5 | zeta at alpha = 1 vs omega*tau/2 (both omega*tau) | 0.0e+00 | < 1e-9 |
| I6 | flexo x, uniform curvature: FEM energy triple vs 3 mu^2/(C11 h^2 kappa33) | 3.570415e-04 vs 3.570415e-04 | rel. diff < 1e-8 (worst 1.8e-10) |
| I7 | flexo Voc, uniform curvature: FEM vs mu*kappa*h/kappa33 | 1.9e-13 | < 1e-10 |
| A2 | every number in the abstract has an independent-check verdict | 3 hua / 11 nahi hua / 5 inputs, 19 tokens | 0 uncovered, 0 stale |
| G1 | piezoelectric share of the bending device (poling y, long faces) at every thickness | 5.7e-07 | < 1e-5 (electrically silent bending mode) |
| G2 | flexo growth with and without the piezoelectric terms | 23.9 vs 31.1 | reported 24 (2 s.f.) uses the real crystal; 31 with e = 0, both graded at 1 % |
| I9 | the same bending field, four poling/electrode pairings: only the long faces collect it, and each pairing with its own permittivity | poled y 3.570e-04 vs 3.570e-04; poled x 1.613e-05 vs 1.613e-05; short-face pairs 7.5e-14 V | rel. diff < 1e-6, short-face charge < 1e-12 |
| I8 | window second-moment factors 1/3, 1/4, 1/5 by quadrature | 3.3e-06 | < 1e-5 |
| P3 | coupled patch test: exact field on one element, assembled vs analytic enthalpy | 7.0e-16 | < 1e-10 (elastic + piezo + flexo + gradient + dielectric) |
| Y1 | coupled matrix symmetric, blocks exact, inertia (96, 14) | |S-S^T|/|S| 1.7e-17, (96, 14, 0), min eig K/|K| -6.7e-17 | < 1e-12, inertia (n_mech, n_phi, 0), one null mode of C_phi |
| H1 | generalized vs Cholesky-standardized pencil, first six modes | 2.3e-04 at h = 1 um (cond K 7.3e+27) | < 1e-3 in w^2: the paper quotes 2 s.f., and this path moves at the 1e-5 level between numeric stacks |
| H2 | L1 weights: b_0 = 1 for every alpha (the 0**0 case) and the cancellation at alpha -> 1 | b_0 ok True, worst rel. error 3.9e-10 | < 1e-8 against a 50-digit Decimal evaluation |
| H3 | time-step independence at alpha < 1: dt, dt/2, dt/4, dt/8 | orders 1.97, 1.50, 0.84, 1.47 | first order: every observed order > 0.8 |
| H4 | modal truncation of the ring-down, 8 and 20 modes against 40 | K_uu 3.0e-04 / 5.1e-05, K_eff < 1e-12 (measured 2.0e-14) | 20 vs 40 < 1e-2 and K_eff 8 vs 40 < 1e-12 (round-off bound) |
| S3 | tornado: +/-10 % in mu, rho, a2, tau against the headline numbers | factor 24 -15.0 % for a2 +10 %, flexo k^2 +19.3 % for mu +10 % | reported, not graded: each row is a scaling law or a solver run |
| E1 | environment recorded for this run | python 3.11.2, numpy 2.4.6, scipy 1.17.1, commit a7c0a2f | a JSON with the versions and the commit exists |
| U1 | h = 1 um flexo k^2 over four equivalent solver paths and 4 numeric stacks | spread 0.182 %, k^2 4.1705e-03..4.1781e-03 | < 0.5 % (quoted to 2 s.f.) |
| U2 | the same spread at h = 10 um | 1.16e-05 % | < 1e-3 % |
| U3 | truncating the secular sum to 12 modes is not an alternative | 84 % off | > 50 % (hence the sum runs over all modes) |
| N3 | no quantity replaced in the round-16 audit has come back | 0 hits of 23 forbidden tokens | 0 hits |
| N4 | every coupling factor recomputed and quoted in one row of the coupling table | 10/10 | all, no averaging |
| N5 | every number in the abstract, the conclusion, the Highlights and the captions is traced to the text or the archive | 46/46 traced, 0 untraced | 0 untraced |
| N2 | the list of unverified numbers cites only numbers still in the manuscript | 35 entries, 0 stale | 0 stale |
| A1 | application table: extensional plane stress is the strongest coupling of the four | 0.4580 | = 0.4580, largest, > 0.4 |
| T1 | piezo k^2 (mode-free) over h = 10 -> 1 um, max/min | 1.0009 | < 1.005 (thickness independent) |
| T2 | piezo k^2, 24x2 vs 48x4, max rel. diff | 5.7e-04 | < 1e-3 |
| T3 | flexo k^2, 48x4 (monotone in h) | 1.74e-04 -> 4.17e-03 | strictly increasing as h falls |
| T4 | flexo k^2, 48x4 vs 96x4 witness | 3.1e-03 | < 0.02 |
| T5 | flexo k^2 at mu = 0 / value (residual) | 6e-07 | < 1e-5 |
| W1 | gradient-energy coefficient: code vs manuscript | 0.5 x int, (1/4)M/((1/20)L)=1.000000000000 | factor 1/2 in the assembly, (1/4)M = (1/20)L, FEM-1 u_R within 2 % |
| P1 | paper figures: vector set written | 12 PDF | = 12 (F1-F9, FB1-FB2, F11_designmap) |
| P2 | orientation sweep rows / k^2 range | 133 rows, 0.3786-0.4677 | 133 rows (114 cuboid + 19 ellipse), k^2 in (0.35, 0.50) |
| N1 | manuscript numbers vs the JSON they came from | 96/96 | all agree |
