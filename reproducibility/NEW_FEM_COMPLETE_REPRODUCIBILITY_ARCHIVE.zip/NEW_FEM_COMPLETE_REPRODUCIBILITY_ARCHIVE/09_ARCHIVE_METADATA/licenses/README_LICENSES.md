# Rights

Project-specific code/data/manuscript license NOT DOCUMENTED / NOT AVAILABLE.
Public repository/archive access is not itself a license. Confirm rights before
redistribution/adaptation/resubmission. Upstream elsarticle class/style dtx/ins,
README/license and per-file notices preserved with exact commit/blob provenance;
class files identify LPPL. Upstream LICENSE is not a project license grant.
Included wheels carry their own embedded dist-info licenses/notices; unmodified
runtime dependencies for tested platform. No OS/interpreter/TeX is bundled.
