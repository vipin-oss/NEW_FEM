# Reconstruction, not bytewise recovery

The previously presented ZIP was not retained in this sandbox and had never
been uploaded to GitHub. This package is reconstructed from the verified source
snapshot. Old 328-file counts, ZIP size/hash and old raw execution logs are NOT
claimed as current artifacts. All new counts/hashes/timings/results come from
this build. Prior known diagnostic bugs are explicitly patched/tested. A fresh
full numerical run and archive audit must finish before release publication.
The user authorized publication to GitHub Release, avoiding another ephemeral link.
