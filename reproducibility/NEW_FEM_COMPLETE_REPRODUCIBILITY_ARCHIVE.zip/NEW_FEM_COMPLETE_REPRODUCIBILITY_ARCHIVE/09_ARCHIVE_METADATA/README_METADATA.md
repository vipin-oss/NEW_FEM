# Metadata/integrity

Inventory records original hashes/inclusion decisions for every200 source files.
Git exports omit personal author/committer email fields; retain hashes/dates/
subjects/statistics. Version provenance distinguishes remote snapshot/local
index and newly reconstructed package. Exact five-file portability patch and
physics-preservation audit expose changes without altering numeric thresholds.
Source catalog records ALL assignments/defaults as expressions, not invented
runtime values. Parameter/run/dataset/result/claim/figure/reference manifests
are explicit; unknowns remain NOT DOCUMENTED/NOT AVAILABLE.
SHA256SUMS covers all payload plus CSV; cannot self-hash. CSV omits itself and
SHA256SUMS to avoid circular hashes. Third-party notices retained. Project license
NOT DOCUMENTED; hashes are integrity, not permission/scientific correctness.
