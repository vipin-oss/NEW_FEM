# Data

All supplied JSON are generated numerical/processed baselines, NOT raw laboratory
measurements. No experimental observations, original upstream FEM-5 material
record, publisher raw benchmark data or calibrated noise data were supplied.
33 baseline JSON files include four historical numeric-stack records, which
are retained but NOT reexecuted on those old stacks in this single-stack test.

Dataset status, purpose, producer, command, precision: dataset_manifest.json.
Nested fields/units: DATA_DICTIONARY.md and data_dictionary_fields.csv.
All important interpreted parameters plus exhaustive source defaults/overrides
are in parameter_manifest.json/source_settings_catalog.json. Unknown units
are explicitly NOT DOCUMENTED rather than guessed from magnitudes.

Regenerate from EMPTY results via REPRODUCE_FROM_SCRATCH.md. Fresh outputs are
labeled test evidence; original baselines remain immutable. Complete field/time
arrays are generally not archived because plotting functions held them in
memory; rerun functions (or modify them to export arrays). No missing history
was fabricated. Final figures are ONLY in 02_OVERLEAF/figures. Supplied duplicate
PNGs were identical; some duplicate PDF bytes/metadata differed, and the
manuscript copy is the single canonical asset. Source hashes record exclusions.
