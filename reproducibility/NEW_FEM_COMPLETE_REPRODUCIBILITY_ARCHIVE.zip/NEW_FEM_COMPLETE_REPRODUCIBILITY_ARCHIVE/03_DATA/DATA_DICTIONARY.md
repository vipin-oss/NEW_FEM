# Data dictionary

Full nested-key dictionary: data_dictionary_fields.csv (1064 paths,
33 JSON files). $=root, [*]=each list entry. Min/max describe observed
baseline values, NOT admissible input bounds or validated operating limits.
Unknown units are NOT DOCUMENTED; consult source expressions/manuscript.

SI solver conventions: m,s,kg,Pa,C/m²,C/m,F/m; plotting suffixes often encode
µm,nm,kHz,µs. Voigt strain [eps_xx,eps_yy,engineering gamma_xy]. x is length,
y thickness, z out of plane; tensors rotate with poling. Mechanical nodal order
[u,ux,uy,uxy,v,vx,vy,vxy]; electric potential is a separate bilinear nodal field.
Static x/(1+x), modal frequency-ratio coupling and unnormalized x differ.
Read coupling_provenance.json before comparing near-0.56/0.46 quantities.
JSON digits are floating-point storage, NOT experimentally established precision.
No raw experimental, statistical uncertainty, FIM/CRLB or calibrated noise
arrays are available. No missing field/unit was fabricated.
