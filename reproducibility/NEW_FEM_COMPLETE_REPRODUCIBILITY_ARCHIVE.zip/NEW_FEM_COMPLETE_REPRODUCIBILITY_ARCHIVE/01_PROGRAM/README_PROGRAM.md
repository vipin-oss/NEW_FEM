# Program

Authoritative language: Python; tested exact interpreter/versions are recorded
in reproduction_test/test_environment.json. Baseline environment.json is an
older supplied record, not this run. Python3.11, numpy2.4.6, scipy1.17.1 and
matplotlib3.11.2 are pinned; all transitive packages are locked. Offline wheels
cover Linux x86_64 CPython3.11 with compatible manylinux/glibc tags only. Python,
OS and TeX distributions themselves are NOT bundled. Other platforms must
install the lock via network and are NOT TESTED. MATLAB version/toolboxes and
verified execution are NOT DOCUMENTED; the mirror has NOT been executed.

From archive root:
python3 -m venv .venv
.venv/bin/python -m pip install --no-index --find-links 01_PROGRAM/wheelhouse -r 01_PROGRAM/requirements-lock.txt
.venv/bin/python 04_REPRODUCTION/prepare.py
.venv/bin/python 04_REPRODUCTION/reproduce.py
.venv/bin/python 04_REPRODUCTION/compare_outputs.py

The wrapper bootstraps demo.json before run_all.py's early readers, then runs
FULL run_all.py (no --reuse) and final audits sequentially. Exact per-script
order is RUN_ORDER.md/run_manifest.json. Outputs are under workspace/results
and workspace/Paper_12, not silently over the baseline. Runtimes vary; use
actual execution.json and stage timings, not old README estimates.

No new tolerance: all 70 original Boolean expressions are retained. No intended
application RNG draws; hash seed0, BLAS/OMP/MKL/NUMEXPR/VECLIB threads1, Agg.
ARPACK v0 is not explicitly set: no universal bitwise-seed guarantee. Default
binary64, near-canceling coupling can move with stack; quoted digits are not
measured physical precision. K_eff and K_uu memory choices are NOT interchangeable.

Original cached-history/summary assumptions were fixed only in package copies:
length_budget missing calibration/Git guard, fresh V2 instead of stale summary,
dead unused summary reads removed from paper audit, report-list shadowing fixed,
and a nonfunctional absolute interpreter example made portable. Exact patch and
physics-preservation audit included; no solver/material/numerical gate changes.

Git is optional for numerical reproduction; synchronization/reference-network
utilities are optional and were NOT executed. sync_to_overleaf.py can PUSH:
use --dry-run and a remote you control. check_refs.py rewrites its audit.
Never claim older fixed-layout audit assumptions still apply to this manuscript.
