from pathlib import Path
import unittest,json,ast,subprocess,sys,tempfile,contextlib,io,importlib.util,shutil
from unittest.mock import patch
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'01_PROGRAM/python'))
def load(n):
 s=importlib.util.spec_from_file_location('test_'+n,R/'01_PROGRAM/python'/(n+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
class ArchiveTests(unittest.TestCase):
 def test_dependencies(self):
  p=subprocess.run([sys.executable,str(R/'04_REPRODUCTION/audit_archive.py')],capture_output=True,text=True);self.assertEqual(p.returncode,0,p.stdout+p.stderr)
 def test_material(self):self.assertEqual(json.loads((R/'09_ARCHIVE_METADATA/parameter_manifest.json').read_text())['material']['values']['rho'],6020)
 def test_all_figures_mapped(self):
  f=json.loads((R/'09_ARCHIVE_METADATA/figure_manifest.json').read_text());a=json.loads((R/'06_VALIDATION/manuscript_dependency_audit.json').read_text());self.assertEqual({x['asset'] for x in f},{x['resolved'] for x in a['graphics']})
 def test_criteria(self):self.assertEqual(len(json.loads((R/'06_VALIDATION/criterion_expressions.json').read_text())),70)
 def test_python_syntax(self):
  for p in (R/'01_PROGRAM/python').glob('*.py'):ast.parse(p.read_text())
 def test_data_paths(self):
  d=json.loads((R/'09_ARCHIVE_METADATA/dataset_manifest.json').read_text());self.assertEqual(len(d),33)
  for x in d:self.assertTrue((R/x['path']).is_file());self.assertTrue((R/x['producer']).is_file())
 def test_no_git(self):
  m=load('length_budget')
  with patch.object(m.subprocess,'run',side_effect=FileNotFoundError):self.assertEqual(m.read('main.tex',rev='NOT_AVAILABLE'),'')
 def test_gradient_without_summary(self):
  m=load('check_gradient_energy')
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp);(p/'verification.json').write_bytes((R/'03_DATA/results/verification.json').read_bytes());m.RES=tmp
   with contextlib.redirect_stdout(io.StringIO()):self.assertEqual(m.main(),0)
   self.assertFalse((p/'summary.json').exists());expected=next(x['value'] for x in json.loads((R/'03_DATA/results/summary.json').read_text())['checks'] if x['id']=='V2');self.assertEqual(json.loads((p/'gradient_energy.json').read_text())['fem1_benchmark_uR_um'],float(expected.split()[0]))
 def test_report_list(self):
  m=load('run_verification')
  with tempfile.TemporaryDirectory() as tmp:
   m.OUT=tmp;m.write_markdown(json.loads((R/'03_DATA/results/verification.json').read_text()));self.assertIn('## V7',(Path(tmp)/'verification.md').read_text())
 def test_number_audit_without_summary(self):
  m=load('check_paper_numbers')
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)
   for q in (R/'03_DATA/results').glob('*.json'):
    if q.name!='summary.json':shutil.copy2(q,p/q.name)
   m.RES=tmp;m.TEX=str(R/'02_OVERLEAF/main.tex')
   with contextlib.redirect_stdout(io.StringIO()):self.assertEqual(m.main(),0)
   self.assertIn('96/96 claims agree',(p/'paper_number_audit.md').read_text());self.assertFalse((p/'summary.json').exists())
if __name__=='__main__':unittest.main()
