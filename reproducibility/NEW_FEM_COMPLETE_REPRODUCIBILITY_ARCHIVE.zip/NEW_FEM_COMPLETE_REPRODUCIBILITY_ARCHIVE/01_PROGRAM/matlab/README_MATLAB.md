# MATLAB mirror — NOT EXECUTED

MATLAB release/toolboxes/minimum version and a tested invocation are NOT DOCUMENTED.
MATLAB NOT AVAILABLE. Python is the documented authority. Inspect mirror entry/
self-tests in your licensed environment before claiming equivalence; record
version, toolbox dependencies, result and discrepancies. No MATLAB validation
has been fabricated or relabeled as reproduced.
